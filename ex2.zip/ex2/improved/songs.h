#ifndef SONG_H
#define SONG_H

#include "sequencer.h"

extern struct Song one_up;
extern struct Song coin;
extern struct Song death;
extern struct Song power_up;
extern struct Song zelda;

#endif
